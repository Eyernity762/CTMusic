import { Song } from './types';

export const TRANSLATIONS = {
  en: {
    playing: "Playing",
    browse: "Browse",
    radio: "Radio",
    upNext: "Up Next",
    upload: "Upload",
    uploading: "Parsing...",
    unknownArtist: "Unknown Artist",
    localUpload: "Local Upload",
    geminiAnalysis: "Sonic Analysis",
    mood: "Mood",
    vibe: "The Vibe",
    texture: "Detected Texture",
    poweredBy: "Powered by Google Gemini",
    listening: "Gemini is listening...",
    noLyrics: "No lyrics available",
    noAnalysis: "No analysis available."
  },
  zh: {
    playing: "正在播放",
    browse: "浏览",
    radio: "电台",
    upNext: "待播清单",
    upload: "上传",
    uploading: "解析中...",
    unknownArtist: "未知艺术家",
    localUpload: "本地上传",
    geminiAnalysis: "听感分析",
    mood: "情绪基调",
    vibe: "氛围描述",
    texture: "音乐质感",
    poweredBy: "由 Google Gemini 提供技术支持",
    listening: "Gemini 正在聆听...",
    noLyrics: "暂无歌词",
    noAnalysis: "暂无分析结果"
  }
};

export const MOCK_SONGS: Song[] = [
  {
    id: '1',
    title: 'Midnight City',
    artist: 'M83',
    album: 'Hurry Up, We\'re Dreaming',
    coverUrl: 'https://picsum.photos/id/1016/800/800',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    colors: ['#2e1065', '#ec4899', '#6366f1'], // Purple, Pink, Indigo
    lyrics: [
      { time: 0, text: "Waiting in a car", translation: "在车里等待" },
      { time: 5, text: "Waiting for a ride in the dark", translation: "在黑暗中等待一段旅程" },
      { time: 10, text: "The night city grows", translation: "夜之城在生长" },
      { time: 15, text: "Look at the horizon glow", translation: "看着地平线发光" },
      { time: 22, text: "Waiting in a car", translation: "在车里等待" },
      { time: 28, text: "Drinking in the lounge", translation: "在休息室饮酒" },
      { time: 35, text: "Following the neon signs", translation: "跟随霓虹灯牌" },
      { time: 42, text: "Waiting for a roar", translation: "等待一声轰鸣" },
      { time: 50, text: "Looking at the mutating skyline", translation: "看着变幻的天际线" },
      { time: 60, text: "The city is my church", translation: "这座城市是我的教堂" },
    ]
  },
  {
    id: '2',
    title: 'Solar Power',
    artist: 'Lorde',
    album: 'Solar Power',
    coverUrl: 'https://picsum.photos/id/1025/800/800',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    colors: ['#d97706', '#fbbf24', '#78350f'], // Warm Amber
    lyrics: [
      { time: 0, text: "I hate the winter", translation: "我讨厌冬天" },
      { time: 4, text: "Can't stand the cold", translation: "受不了寒冷" },
      { time: 8, text: "I tend to cancel all the plans", translation: "我倾向于取消所有计划" },
      { time: 12, text: "But when the heat comes", translation: "但当热浪来袭" },
      { time: 16, text: "Something takes a hold", translation: "某种东西占据了我" },
      { time: 20, text: "Can I kick it?", translation: "我可以开始吗？" },
      { time: 24, text: "Yeah, I can", translation: "是的，我可以" },
    ]
  },
  {
    id: '3',
    title: 'Ocean Eyes',
    artist: 'Billie Eilish',
    album: 'Don\'t Smile at Me',
    coverUrl: 'https://picsum.photos/id/1050/800/800',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    colors: ['#155e75', '#0891b2', '#cffafe'], // Deep Cyan
    lyrics: [
      { time: 0, text: "I've been watching you", translation: "我一直在注视着你" },
      { time: 5, text: "For some time", translation: "有一段时间了" },
      { time: 10, text: "Can't stop staring", translation: "无法停止凝视" },
      { time: 15, text: "At those ocean eyes", translation: "那双像海洋一样的眼睛" },
      { time: 20, text: "Burning cities", translation: "燃烧的城市" },
      { time: 25, text: "And napalm skies", translation: "和凝固汽油弹般的天空" },
      { time: 30, text: "Fifteen flares inside those ocean eyes", translation: "那双海眼中闪烁着十五束光芒" },
      { time: 35, text: "Your ocean eyes", translation: "你的海洋之眼" },
    ]
  }
];
