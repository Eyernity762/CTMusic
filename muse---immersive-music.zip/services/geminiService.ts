import { GoogleGenAI, Type } from "@google/genai";
import { Song, AnalysisResult } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeSong = async (song: Song): Promise<AnalysisResult> => {
  const lyricsText = song.lyrics.map(l => l.text).join("\n");
  
  const prompt = `
    Analyze the following song and provide a structured JSON response.
    
    Song: ${song.title} by ${song.artist}
    Lyrics Snippet:
    ${lyricsText.substring(0, 500)}...
    
    Provide:
    1. A "mood" (1-2 words, e.g., "Melancholic Dreamy").
    2. A "description" (a creative, music-critic style description of the vibe in under 40 words).
    3. "instruments" (an array of 3-4 key imagined instruments or textures based on the vibe).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mood: { type: Type.STRING },
            description: { type: Type.STRING },
            instruments: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AnalysisResult;
    }
    throw new Error("No response text");
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    return {
      mood: "Atmospheric",
      description: "An immersive sonic journey that transcends the ordinary.",
      instruments: ["Synthesizer", "Vocals", "Bass"]
    };
  }
};

export const parseAudioWithGemini = async (base64Audio: string, mimeType: string): Promise<Partial<Song>> => {
  // If file is too large or base64 is empty, fail fast
  if (!base64Audio || base64Audio.length < 100) {
      throw new Error("Invalid audio data");
  }

  const prompt = `
    Listen to this audio snippet. 
    1. Identify Song Title, Artist, Album. If unknown, infer a style for Title/Artist (e.g., "Untitled Jazz", "Unknown Artist").
    2. Suggest 3 colors (hex codes) that match the song's mood. Make them elegant and muted, not too neon.
    3. Transcribe up to 4 lines of lyrics with timestamps if vocals exist. If instrumental, return empty lyrics.
    
    Return JSON.
  `;

  try {
    // Create a timeout promise to prevent hanging indefinitely
    const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Gemini Request Timeout")), 15000)
    );

    const apiCallPromise = ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Audio
          }
        },
        { text: prompt }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            artist: { type: Type.STRING },
            album: { type: Type.STRING },
            colors: { type: Type.ARRAY, items: { type: Type.STRING } },
            lyrics: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  time: { type: Type.NUMBER },
                  text: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    // Race the API call against the timeout
    const response: any = await Promise.race([apiCallPromise, timeoutPromise]);

    if (response.text) {
      return JSON.parse(response.text);
    }
    throw new Error("No response from Gemini");
  } catch (error) {
    console.error("Gemini Audio Parsing Failed:", error);
    throw error;
  }
};
