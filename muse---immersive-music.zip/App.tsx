import React, { useState, useRef, useEffect } from 'react';
import { FluidBackground } from './components/FluidBackground';
import { PlayerControls } from './components/PlayerControls';
import { LyricsView } from './components/LyricsView';
import { SongAnalysis } from './components/SongAnalysis';
import { MOCK_SONGS, TRANSLATIONS } from './constants';
import { Song, AnalysisResult } from './types';
import { analyzeSong, parseAudioWithGemini } from './services/geminiService';
import { ListMusic, ChevronDown } from 'lucide-react';

// Comfortable color palettes for fallback
const COMFORT_COLORS = [
  ['#4c1d95', '#a21caf', '#db2777'], // Deep Purple -> Pink
  ['#0f172a', '#1e293b', '#334155'], // Deep Slate
  ['#7c2d12', '#9a3412', '#c2410c'], // Warm Rust
  ['#064e3b', '#065f46', '#047857'], // Deep Green
  ['#0c4a6e', '#075985', '#0369a1'], // Deep Ocean
];

const getRandomComfortColors = () => COMFORT_COLORS[Math.floor(Math.random() * COMFORT_COLORS.length)];

const App: React.FC = () => {
  // Localization
  const [lang, setLang] = useState<'en' | 'zh'>('en');

  useEffect(() => {
    // Detect browser language
    const browserLang = navigator.language;
    if (browserLang.toLowerCase().startsWith('zh')) {
      setLang('zh');
    } else {
      setLang('en');
    }
  }, []);

  const t = TRANSLATIONS[lang];

  // Songs State
  const [songs, setSongs] = useState<Song[]>(MOCK_SONGS);
  
  // Player State
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [showPlaylist, setShowPlaylist] = useState(false);
  
  // AI State
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [analysisData, setAnalysisData] = useState<AnalysisResult | null>(null);

  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const currentSong = songs[currentSongIndex];

  // Audio Handlers
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => {
            console.error("Playback failed", e);
            setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentSongIndex]);

  useEffect(() => {
    if(audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setProgress(time);
    }
  };

  const handleNext = () => {
    setCurrentSongIndex((prev) => (prev + 1) % songs.length);
    setIsPlaying(true);
  };

  const handlePrev = () => {
    setCurrentSongIndex((prev) => (prev - 1 + songs.length) % songs.length);
    setIsPlaying(true);
  };

  // Upload & AI Parsing Logic
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      
      try {
        const objectUrl = URL.createObjectURL(file);
        
        // Safety: Limit file size to 10MB for Gemini Parsing to prevent hanging
        const MAX_SIZE = 10 * 1024 * 1024; // 10MB
        const isTooLarge = file.size > MAX_SIZE;

        let newSong: Song;

        if (isTooLarge) {
            console.warn("File too large for AI parsing, using fallback.");
            newSong = createFallbackSong(file, objectUrl);
            setSongs(prev => [...prev, newSong]);
            setCurrentSongIndex(songs.length);
            setIsPlaying(true);
            setShowPlaylist(false);
            setIsUploading(false);
            return;
        }
        
        const reader = new FileReader();
        reader.readAsDataURL(file);
        
        reader.onloadend = async () => {
          const base64String = (reader.result as string).split(',')[1];
          
          try {
             // Attempt Gemini Parse
             const metadata = await parseAudioWithGemini(base64String, file.type || 'audio/mp3');
             
             newSong = {
               id: `local-${Date.now()}`,
               title: metadata.title || file.name.replace(/\.[^/.]+$/, ""),
               artist: metadata.artist || t.unknownArtist,
               album: metadata.album || t.localUpload,
               coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800&auto=format&fit=crop', 
               audioUrl: objectUrl,
               colors: metadata.colors || getRandomComfortColors(),
               lyrics: metadata.lyrics || []
             };
          } catch (e) {
             console.error("Gemini Parse Error, falling back to basic info", e);
             newSong = createFallbackSong(file, objectUrl);
          }
          
          setSongs(prev => [...prev, newSong]);
          setCurrentSongIndex(songs.length); 
          setIsPlaying(true);
          setShowPlaylist(false);
          setIsUploading(false);
        };
      } catch (e) {
        console.error("Upload failed", e);
        setIsUploading(false);
      }
    }
  };

  const createFallbackSong = (file: File, objectUrl: string): Song => ({
    id: `local-${Date.now()}`,
    title: file.name.replace(/\.[^/.]+$/, ""),
    artist: t.unknownArtist,
    album: t.localUpload,
    coverUrl: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=800&auto=format&fit=crop',
    audioUrl: objectUrl,
    colors: getRandomComfortColors(),
    lyrics: []
  });

  // Vibe Check
  const handleAnalyze = async () => {
    setShowAnalysis(true);
    if (!analysisData) {
      setIsAnalyzing(true);
      try {
        const result = await analyzeSong(currentSong);
        setAnalysisData(result);
      } catch (err) {
        console.error(err);
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  return (
    <div className="relative w-full h-[100dvh] bg-black overflow-hidden font-sans select-none text-white flex flex-col">
      <audio
        ref={audioRef}
        src={currentSong.audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleNext}
      />
      
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="audio/*" 
        className="hidden" 
      />

      <FluidBackground colors={currentSong.colors} isPlaying={isPlaying} />

      {/* Main Layout - Responsive Grid/Flex */}
      <div className="relative z-10 w-full h-full flex flex-col md:flex-row p-4 md:p-10 lg:p-12 gap-6 md:gap-12 max-w-[1920px] mx-auto">
        
        {/* Left Column: Fixed Info & Controls */}
        <div className="w-full md:w-[45%] lg:w-[40%] flex flex-col h-full md:justify-center z-20 pt-8 md:pt-0">
           {/* Top Bar for Mobile */}
           <div className="md:hidden absolute top-0 left-0 right-0 flex justify-between p-4 bg-gradient-to-b from-black/40 to-transparent">
               <div className="w-10 h-1 bg-white/20 rounded-full absolute top-3 left-1/2 -translate-x-1/2" />
               <div /> {/* Spacer */}
               <button onClick={() => setShowPlaylist(true)} className="p-2 bg-white/10 rounded-full backdrop-blur">
                  <ListMusic size={20} />
               </button>
           </div>

           {/* Album Art */}
           <div className={`
             relative w-full aspect-square max-w-[300px] sm:max-w-[340px] md:max-w-[420px] mx-auto md:mx-0
             rounded-2xl shadow-2xl transition-all duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] mb-6 md:mb-12 mt-4 md:mt-0
             ${isPlaying ? 'scale-100 shadow-[0_20px_60px_rgba(0,0,0,0.5)]' : 'scale-95 shadow-[0_10px_30px_rgba(0,0,0,0.3)]'}
           `}>
             <img 
               src={currentSong.coverUrl} 
               className="w-full h-full object-cover rounded-2xl border border-white/10"
               alt="Album Art"
             />
             {isUploading && (
                <div className="absolute inset-0 bg-black/60 rounded-2xl flex flex-col items-center justify-center backdrop-blur-md">
                   <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin mb-3"/>
                   <span className="text-sm font-medium tracking-wide animate-pulse">{t.uploading}</span>
                </div>
             )}
           </div>

           {/* Song Info */}
           <div className="mb-6 md:mb-10 text-center md:text-left px-4 md:px-0">
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold tracking-tight text-white mb-2 leading-tight line-clamp-1">
                {currentSong.title}
              </h1>
              <h2 className="text-lg md:text-xl text-white/60 font-medium tracking-wide line-clamp-1">
                {currentSong.artist} <span className="text-white/30 mx-1">•</span> {currentSong.album}
              </h2>
           </div>

           {/* Controls Container - Width constrained to match Art */}
           <div className="w-full max-w-[340px] md:max-w-[420px] mx-auto md:mx-0 pb-8 md:pb-0">
              <PlayerControls 
                isPlaying={isPlaying}
                onPlayPause={() => setIsPlaying(!isPlaying)}
                onNext={handleNext}
                onPrev={handlePrev}
                progress={progress}
                duration={duration}
                onSeek={handleSeek}
                volume={volume}
                onVolumeChange={setVolume}
                onAnalyze={handleAnalyze}
                isAnalyzing={isAnalyzing}
                onUploadClick={() => fileInputRef.current?.click()}
                isUploading={isUploading}
              />
           </div>
        </div>

        {/* Right Column: Scrollable Lyrics (Desktop) */}
        <div className="hidden md:block flex-1 h-full overflow-hidden relative">
           <LyricsView 
             lyrics={currentSong.lyrics} 
             currentTime={progress} 
             onLineClick={handleSeek}
             isExpanded={true}
             lang={lang}
           />
        </div>

        {/* Mobile Lyrics (Below controls, fills remaining space) */}
        <div className="md:hidden flex-1 overflow-hidden relative -mx-4">
             <div className="absolute inset-0 mask-gradient-top-bottom">
               <LyricsView 
                lyrics={currentSong.lyrics} 
                currentTime={progress} 
                onLineClick={handleSeek}
                isExpanded={true}
                lang={lang}
              />
             </div>
        </div>
      </div>

      {/* Desktop Playlist Toggle */}
      <div className="hidden md:block absolute top-8 right-8 z-50">
         <button 
           onClick={() => setShowPlaylist(!showPlaylist)}
           className="p-3 bg-white/5 hover:bg-white/10 backdrop-blur-md border border-white/5 rounded-full transition-all text-white/80 hover:text-white hover:scale-105 active:scale-95"
         >
           <ListMusic size={24} />
         </button>
      </div>

       {/* Playlist Drawer (Overlay) */}
       <div className={`
         absolute top-0 right-0 bottom-0 w-full sm:w-[380px] bg-[#121212]/95 backdrop-blur-3xl border-l border-white/10 z-50 transform transition-transform duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] p-6 overflow-y-auto shadow-2xl
         ${showPlaylist ? 'translate-x-0' : 'translate-x-full'}
      `}>
          <div className="flex justify-between items-center mb-6 sticky top-0 bg-[#121212]/0 backdrop-blur-sm pb-2 z-10">
             <h2 className="text-xl font-bold tracking-tight">{t.upNext}</h2>
             <button onClick={() => setShowPlaylist(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <ChevronDown />
             </button>
          </div>
          <div className="space-y-1 pb-10">
             {songs.map((song, idx) => (
                <div 
                   key={song.id}
                   onClick={() => {
                     setCurrentSongIndex(idx);
                     setIsPlaying(true);
                     setAnalysisData(null);
                   }}
                   className={`
                     flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all duration-200 group
                     ${idx === currentSongIndex ? 'bg-white/10' : 'hover:bg-white/5'}
                   `}
                >
                   <div className="relative w-11 h-11 flex-none rounded-md overflow-hidden shadow-sm">
                      <img src={song.coverUrl} className="w-full h-full object-cover" />
                      {idx === currentSongIndex && isPlaying && (
                         <div className="absolute inset-0 bg-black/50 flex items-center justify-center gap-[2px]">
                             <div className="w-[2px] h-3 bg-white animate-[bounce_1s_infinite]" />
                             <div className="w-[2px] h-4 bg-white animate-[bounce_1.2s_infinite] delay-75" />
                             <div className="w-[2px] h-2 bg-white animate-[bounce_0.8s_infinite] delay-150" />
                         </div>
                      )}
                   </div>
                   <div className="flex-1 min-w-0 flex flex-col justify-center">
                      <p className={`font-medium text-sm truncate leading-tight mb-0.5 ${idx === currentSongIndex ? 'text-white' : 'text-white/90'}`}>
                        {song.title}
                      </p>
                      <p className="text-xs text-white/50 truncate font-medium">
                        {song.artist}
                      </p>
                   </div>
                </div>
             ))}
          </div>
      </div>

      <SongAnalysis 
        isOpen={showAnalysis} 
        onClose={() => setShowAnalysis(false)} 
        analysis={analysisData}
        isLoading={isAnalyzing}
        lang={lang}
      />
    </div>
  );
};

export default App;
