export interface LyricLine {
  time: number; // in seconds
  text: string;
  translation?: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  audioUrl: string;
  colors: string[]; // [primary, secondary, accent] for fluid background
  lyrics: LyricLine[];
}

export interface AnalysisResult {
  mood: string;
  description: string;
  instruments: string[];
}
